## CSE 5545 Advanced Computer Graphics

### Lab 2 PBRT Shapes and Ray - Object intersection

### Name: Yongfeng Qiu

### Email: qiu.722@osu.edu

----

### How to run my code

```shell
# copy api.cpp, MyLog.h, integrator to src/core/
# copy bvh.cpp to src/accelerators/
# copy snowman.h, snowman.cpp, ChristmasTree.h, ChristmasTree.cpp to src/shape
# copy ChristmasTree.pbrt to scene/
# copy run.sh to build/
mkdir buuild && cd build
cmake ..
./run.sh ChristmasTree true 
# ChristmasTree : which pbrt you wanna use
# true / false  : show render result or not
```



### Step 1: Plan your composite shape

For this part, I used disk, cylinder, cone and sphere to build a Christmas tree.

### Step 2: Create the composite shape class

- Please check with ChristmasTree.cpp and ChristmasTree.h

![pic](./Result/ChristmasTree.png)

- This is a description of my class.

 ![pic](./Result/ChristmasTree_Class.png)

### Step 3: Create Your own scene

- Please check with ChristmasTree.pbrt
- In this scene i use the 
  - sphere
  - cone
  - cylinder
  - disk
  - tirangle mesh
  - Spot light
  - sphere area light


![pic](./Result/ChristmasTree1.png)

![pic](./Result/ChristmasTree2.png)

<img src="./Result/ChristmasTree3.png" alt="pic" style="zoom: 25%;" />

### Stpe 4: Profilling

I have implemented my own counting function. For the specific implementation code, please refer to MyLog.h. 

I compared my code results with the STAT_COUNTER results of PBRT V3. The two are the same.

- run with PBRT V3 STAT_COUNTER

![pic](./Result/step4.png)

- run with my code

![pic](./Result/step4_my.png)

In the last part, for a total of 361 tiles, I didn't save their specific screenshots. You can run the code to get or read this [file](./Result/output.txt).

It is very easy to use my code, which is a C++ head only code.

Attach a example here

```c++
#include "MyLog.h"

yf::INCREMENT_STAT_COUNTER("SNOWMAN/MY_SNOWMAN_TOTAL_RAYS", 1);
// The first parameter: the quantity you want to count. At the same time, it will also be the final output category.
// The second parameter: The amount of each increase

yf::MyStatManager::ReportAll();
// Output the number of all statistics. 
// I set the specific class to static within the code and meet the singleton mode. 
// You should only call it once in the whole code. 
// In the fourth part, I put it in Snowman's destructor.
```



- **The total number of rays cast for the whole scene.**

300 x 300 x 4 = 360000

Please check with **integrator.cpp**

In the rendering function, we can find that the camera generates rays here, and we can count all the ray here.

```c++
// integratior.cpp

// in line 50
STAT_COUNTER("SNOWMAN/SNOWMAN_TOTAL_RAYS", nTotalRayTraces); 				// work with pbrt code version

// in line 296
++nTotalRayTraces;																									// work with pbrt code version
yf::INCREMENT_STAT_COUNTER("SNOWMAN/MY_SNOWMAN_TOTAL_RAYS", 1);	    // work with my code version
```



- **The number of rays that intersect with bounding boxes.**

Please check with **bvh.cpp**

We can find the ray and bounding box here for intersection testing. So we can count the ray that intersects the bounding box here. In this part, I consider the element of floor.

```c++
// bvh.cpp

// in line 49
STAT_COUNTER("SNOWMAN/SNOWMAN_BOUNDING_BOX_INTERSECTION", nBoundingBoxIntersectionTests);  // work with pbrt code version

// in line 677
++nBoundingBoxIntersectionTests;																													// work with pbrt code version
yf::INCREMENT_STAT_COUNTER("SNOWMAN/MY_SNOWMAN_BOUNDING_BOX_INTERSECTION", 1);						// work with my code version
```



- **The number of rays that intersect with any object.**

Please check with **snowman.cpp**

If the ray hit the sphere A or sphere B, it will be counted. 

In this part, I am not consider the element of floor.

```c++
// in snowman.cpp

// in line 13
STAT_COUNTER("SNOWMAN/MYSNOWMAN_ANY_SHAPE_INTERSECTION", nCompositeShapeIntersectionTests);

// in function Insterect
 if (hit1 || hit2)
{
	yf::INCREMENT_STAT_COUNTER("SNOWMAN/MYSNOWMAN_ANY_SHAPE_INTERSECTION", 1);
	++nCompositeShapeIntersectionTests;
}
```



- **The number of rays that hit each single object within the composite shape.**



Please check with **snowman.cpp**

The snowman consists of two spheres, so it needs to be counted separately. 

So the sum of answer to this question is just equal to the answer to the previous question.

 In this part, I am not consider the element of floor.

```c++
// in snowman.cpp

// in line 11
STAT_COUNTER("SNOWMAN/SNOWMAN_ANY_OBJECT_INTERSECTION1", nAnyObjectIntersectionTests1);
STAT_COUNTER("SNOWMAN/SNOWMAN_ANY_OBJECT_INTERSECTION2", nAnyObjectIntersectionTests2);

// in function Insterect
if (hit1) 
{
	++nAnyObjectIntersectionTests1;
  yf::INCREMENT_STAT_COUNTER("SNOWMAN/MY_SNOWMAN_ANY_OBJECT_INTERSECTION1", 1);
}
else if (hit2)
{
  ++nAnyObjectIntersectionTests2;
  yf::INCREMENT_STAT_COUNTER("SNOWMAN/MY_SNOWMAN_ANY_OBJECT_INTERSECTION2", 1);
}
```



- **The number of rays that intersect with any object in each image tile.**

Please check with **integrator.cpp**

First of all, count how many tiles there are, and the result is 361. That is, 19 * 19. Similarly, in render, if the ray hits the scene, count it.

The reason why I use intersectP instead of insterect is that using the former will cause the values of the previous questions to be repeated.

```c++
// in integratior.cpp

std::atomic<int> per_tile_ray_count;
std::mutex vectorMutex;

if (rayWeight > 0)
{
	L = Li(ray, scene, *tileSampler, arena);
	if (scene.IntersectP(ray)
	{
  	++nForTest; 
		per_tile_ray_count++; //per_tile_ray_count is std::atomic<int> type
	}
} 

// print the result after picture compositing
```

