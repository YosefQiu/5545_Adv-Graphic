**01 introduction** Overview 

1. 两种integrator
2. PBRT framework
3. define
4. code

**02 geo transfer**

1. 坐标变换，概念
2. 为什么要用这些坐标

**03 shape**

**04 bounding  box**

**05 color** 



