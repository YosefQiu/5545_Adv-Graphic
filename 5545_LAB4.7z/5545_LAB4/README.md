## CSE 5545 Advanced Computer Graphics

### Lab 4 Area light construction and sampling

### Name: Yongfeng Qiu

### Email: qiu.722@osu.edu

----

### How to run my code

```shell
# copy api.cpp, interaction.h to src/core/
# copy compmat.h compmat.h.cpp to src/material/
# copy ChristmasTree.h, ChristmasTree.cpp cone.cpp to src/shape
# copy Scene.pbrt to scene/
# copy models to scene/
# copy run.sh to build/
mkdir buuild && cd build
cmake ..
./run.sh Scene true 
# Scene : which pbrt you wanna use
# true / false  : show render result or not
```



### Task 1: Composite Shape Light Source

I added the Sample function to the code of Lab 2. Because my model is composed of multiple objects. So I use a method similar to the inverse method to achieve it.

```c++
// In ChristmasTree.cpp
Interaction ChristmasTree::Sample(const Point2f &u, Float *pdf) const {
    float totalArea = Area();
    std::vector<float> partsAreas = {
        mBaseNode.mCylinder->Area(),
        mBaseNode.mDisk->Area(),
        mTreeNode.mCylinder->Area(),
        mTreeNode.mSphere->Area()
    };
    for (auto& cone : mTreeNode.mCone) {
        partsAreas.push_back(cone->Area());
    }

    std::vector<float> cdf;
    cdf.push_back(0); 
    for (size_t i = 0; i < partsAreas.size(); ++i) {
        cdf.push_back(cdf.back() + partsAreas[i] / totalArea);
    }

    size_t partIndex = std::lower_bound(cdf.begin(), cdf.end(), u[0]) - cdf.begin() - 1;
    Interaction sample;

    float remappedU0 = (u[0] - cdf[partIndex]) / (cdf[partIndex + 1] - cdf[partIndex]);
    Point2f remappedU = Point2f(remappedU0, u[1]);

    if (partIndex == 0) {
        sample = mBaseNode.mCylinder->Sample(remappedU, pdf);
    } else if (partIndex == 1) {
        sample = mBaseNode.mDisk->Sample(remappedU, pdf);
    } else if (partIndex == 2) {
        sample = mTreeNode.mCylinder->Sample(remappedU, pdf);
    } else if (partIndex == 3) {
        sample = mTreeNode.mSphere->Sample(remappedU, pdf);
    } else {
        sample = mTreeNode.mCone[partIndex - 4]->Sample(remappedU, pdf);
    }

    *pdf *= partsAreas[partIndex] / totalArea;

    return sample;
}
```

Snowman scene based on my method

![pic](./Result/SnowMan.png)

My scene in Lab 3

![pic](./Result/Scene.png)

Based on my current method. And turn off other areas of light.

![pic](./Result/Scene1.png)

The final scene.

![pic](./Result/Scene2.png)

- The data set can be downloaded from here.
- https://drive.google.com/drive/folders/1Ld9pU4BlNLd6A0poGMb4EFkMibvAa6BN?usp=drive_link
